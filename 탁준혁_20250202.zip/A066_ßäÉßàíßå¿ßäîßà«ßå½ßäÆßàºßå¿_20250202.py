n = input()
sorted_n = sorted(str(n), reverse=True)
print(''.join(sorted_n))