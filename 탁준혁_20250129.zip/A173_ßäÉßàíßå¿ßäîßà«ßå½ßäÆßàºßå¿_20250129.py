def solution(numbers):    
    return 45 - sum(numbers)